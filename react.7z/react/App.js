import React, { Component } from 'react';
import { AppState, Image, KeyboardAvoidingView, StyleSheet, Text, TextInput, ScrollView, StatusBar, View, YellowBox} from 'react-native';

import Chat from './src/views/Chat';
import InputComponent from './src/components/InputComponent';

import IntentRouter from './src/utils/IntentRouter';
import ResolveEntities from './src/utils/ResolveEntities';
import GetWitResponse from './src/utils/GetWitResponse';
import GetSuggestionResponse from './src/utils/GetSuggestionResponse';

YellowBox.ignoreWarnings(['Warning: ...']);
YellowBox.ignoreWarnings(['Remote debugger']);

export default class App extends Component {
	constructor() {
		super();
		this.state = {
			value: '',
			msg: '',
			data: {},
			summary: '',
			botMsg: '',
			appState: AppState.currentState,
			sessionId: 0
		}
	}

	componentDidMount() {
		const id = Math.floor(Math.random()*100);
		this.setState({
			sessionId: id
		})
		AppState.addEventListener('change', this._handleAppStateChange);
	}

	componentWillUnmount() {
    	AppState.removeEventListener('change', this._handleAppStateChange);
	}

	shouldComponentUpdate(nextProps, nextState) {
		const prevStateVal = JSON.stringify(this.state.msg);
		const nextStateVal = JSON.stringify(nextState.msg);
		return prevStateVal !== nextStateVal;
	}

	_handleAppStateChange = (nextAppState) => {
		if (this.state.appState.match(/inactive|background/) && nextAppState === 'active') {
			console.log('App has come to the foreground!')
		}
		this.setState({appState: nextAppState});
	}

	onUpdate (value) {
		this.setState({
			value
		});
	}

	getResponse = async (msgd, value) => {
		const skipWit = value ? false : true ;
		let witData, resolvedEntities;

		if (skipWit) {
			// call to Wit.ai for intents and entities
			witData = await GetWitResponse(msgd);
			// process response from Wit and extract intent and entities
			resolvedEntities =  await ResolveEntities(witData);
		} else {
			let data = this.directKGResponse(msgd, value);
			witData = data[0];
			resolvedEntities= data[1];
		}

		const msg = await IntentRouter(witData, resolvedEntities);

		this.setState({
			msg
		});
	}

	onSubmit (msg, value) {
		this.getResponse(msg, value);
		this.setState({
			value: '',
			msg: [{user: msg, type: 'text'}]
		});
	}

	directKGResponse (msg, value) {
		let witData = {entities:{intent:[{value:''}]}};
		let resolvedEntities= {
			intent: 'get_info',
			entities: value.isMovie ? {movie: value.name} : {person: value.name}
		};
		witData.entities.intent[0].value = 'get_info';

		this.setState({
			value: '',
			msg: [{user: msg, type: 'text'}]
		});

		// const msgd = await IntentRouter(witData, resolvedEntities);
		// this.setState({
		// 	msg:msgd
		// });
		return [witData, resolvedEntities];
	}

	onCardPress = ({value}) => {
		value.isMovie ?
			this.onSubmit(`Tell me about the movie ${value.name}`, value) :
			this.onSubmit(`Tell me about ${value.name}`, value)
	}

	onButtonPress = ({intent, personName}) => {
		let general = ["CoActors", "TopMovies", "UpcomingMovies"];
		let msg;
		if (general.indexOf(intent) > -1) {
			msg = `${intent} of ${personName}`;
			this.suggestionResponse(intent, personName);
		} else {
			msg = `Show me ${intent} movies.`;
			this.onSubmit(msg);
		}
		this.setState({
			value: '',
			msg: [{user: msg, type: 'text'}]
		});
	}

	suggestionResponse = async (intent, personName) => {
		const msg = await GetSuggestionResponse(intent, personName);
		this.setState({
			msg
		});
	}

  	render() {
		return (
			<View style={styles.container}>
				<View style={styles.header}>
					<StatusBar backgroundColor="lightseagreen" barStyle="light-content" />
					<Text style={styles.title}>
						Knowledge Graph
					</Text>
				</View>
				<Chat msg={this.state.msg}  cardPress={this.onCardPress} buttonPress={this.onButtonPress} />
					<InputComponent
						onUpdate = {(value) => this.onUpdate(value)}
						value={this.state.value}
						onSubmit={(value) => this.onSubmit(value)}
					/>
			</View>
		);
	}
}
const styles = StyleSheet.create({
	container: {
		flex: 1, backgroundColor: '#fff'
	},
	header: {
		height: 50,
		backgroundColor: 'lightseagreen',
		alignItems: 'center',
		justifyContent: 'flex-end',
		padding: 10,
	},
	title: {
		color: 'white',
		fontWeight: 'bold',
		fontSize: 24
	},
});
