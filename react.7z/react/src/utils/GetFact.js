import GetKGResponse from './GetKGResponse';

GetFact = async ({intent, entities}) => {
	let processedData;
	const data = await GetKGResponse(intent, entities);
	return data && data.length ? data[0] : 'Sorry! No data available.';
}

export default GetFact;