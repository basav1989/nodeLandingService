import GetKGResponse from './GetKGResponse';

GetMovies = async ({intent, entities}) => {
	const data = await GetKGResponse(intent, entities);
	if (intent === 'get_cast') {
		data.map((item) => item.isMovie = false);
	} else {
		data.map((item) => item.isMovie = true);
	}

	data.map((item) => {
		item.image = `http://10.221.31.64:5200/${item.name}.jpg`;
		return item;
	});

	// data.isMovie = data.length && data[0].genre ? true : false;
	return data ? data : null;
}

export default GetMovies;