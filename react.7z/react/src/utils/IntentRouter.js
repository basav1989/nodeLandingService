import GetInfo from './GetInfo';
import GetMovies from './GetMovies';
import GetFact from './GetFact';


IntentRouter = async (witData, resolvedEntities) => {
	let msg;
	if (!resolvedEntities) {
		return msg = [{bot:`Sorry!! I didn't get you...

		You can ask about any Movie or an Actor.
				`, type: 'customCard'}];
	}
	if (resolvedEntities.intent === 'get_info') {
		//get data from KG api
		const data = await GetInfo(resolvedEntities);
		msg = checkData(data, witData);
	} else if (
		resolvedEntities.intent === 'get_movies_by_time_and_person' ||
		resolvedEntities.intent === 'get_cast'  ||
		resolvedEntities.intent === 'get_person_best_movies' ||
		resolvedEntities.intent === 'get_genre_based_movies') {
		//get data from KG api
		const data = await GetMovies(resolvedEntities);
		if (witData.entities.intent[0].value === "get_person_by_role" && data && data.length) {
			let person = [];
			data.forEach(dt => {
				if (dt.roles === witData.entities.personRole[0].value) {
					person.push(dt);
				}
			});
			msg = checkData(person, witData);
		} else if (witData.entities.intent[0].value === "get_cast" && data && data.length && witData.entities.personRole) {
			let person = [];
			data.forEach(dt => {
				if (dt.roles === 'actor' || dt.roles === 'actress') {
					person.push(dt.name);
				}
			});

			msg = checkData(person, witData);
		} else {
			msg = checkData(data, witData);
    	}
	} else if (resolvedEntities.intent === 'greetings') {
		msg=[
		{bot: `Hi there!!!`, type: 'text'},
		{bot:'You can ask me about any Movie or an Actor.', type: 'text'}
		];
	}  else if (resolvedEntities.intent === 'get_fact_verification') {
		const data = await GetFact(resolvedEntities);
		msg = [{bot: data, type: 'text'}];
	} else if (resolvedEntities.intent === 'get_movies_people_combo' || resolvedEntities.intent === 'get_top_movies_by_time') {
		const data = await GetMovies(resolvedEntities);
		msg = checkData(data, witData);

	} else if (resolvedEntities.intent) {
		msg=[{bot: 'Sorry! We did not cover this intent. Please try something else.', type: 'text'}]
	} else {
		msg = [{bot:`Sorry!! I didn't get you...

		You can ask about any Movie or an Actor.
				`, type: 'customCard'}];
	}

	return msg;
}

function checkData (data,witData) {
	let msg;
	if (data) {
		msg = sendMessage(data, witData);
	} else {
		msg = [{bot:`Sorry!!No data available right now.`, type: 'customCard'}];
	}
	return msg;
}

function sendMessage (data, witData) {
	let msg;
	let suggestionButtons;
	if (data.length > 0) {
		suggestionButtons = data.suggestions || data[0].suggestions ? {
			bot: 'suggestions',
			type: data.length > 1 ? '' : 'buttonList',
			data: data.length > 1 ? [] : data[0]
		} : {};

		msg = [
		{bot: data.length > 1 ?
			'I got the below list.' :
			'Here is what I got...', type: 'text'
		},{
 			bot: witData.entities.intent[0].value,
 			type: data.length > 1 ? 'horizontalCardList' : 'imageCard',
			data: data.length > 1 ? data : data[0]
		}, suggestionButtons];
	} else {
		msg= [{bot: `Sorry! We don't have any data. Could you try again?`, type: 'text'}];
	}
	return msg;
}
export {sendMessage, checkData};
export default IntentRouter;