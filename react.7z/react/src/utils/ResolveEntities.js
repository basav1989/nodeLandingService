function ResolveEntities (data) {
	if (!data.entities) {
		return {
			intent: null
		}
	}
	if ((data.entities.intent && data.entities.intent[0].value === 'get_info') &&
	 (data.entities.personName || data.entities.movie_name || data.entities.notable_person)) {
		let person;
			if (data.entities.personName && data.entities.personName[0].value){
				person = data.entities.personName[0].value;
			} else if (data.entities.notable_person && data.entities.notable_person[0].value.name) {
				person = data.entities.notable_person[0].value.name;
			}
		return (person) ? {
			intent: 'get_info',
			entities: {person: modifyText(person)}
		} : {
			intent: 'get_info',
			entities: {movie: modifyText(data.entities.movie_name[0].value)}
		}
	} else if((data.entities.intent && data.entities.intent[0].value === 'get_movies_by_time_and_person') &&
	 ((data.entities.personName && data.entities.personName.length > 0) ||
	 	(data.entities.notable_person && data.entities.notable_person.length > 0)
	 ) ) {

		let person, time, genre, role, entities;
			if (data.entities.personName && data.entities.personName[0].value){
				person = data.entities.personName[0].value;
			} else if (data.entities.notable_person && data.entities.notable_person[0].value.name) {
				person = data.entities.notable_person[0].value.name;
			}
		  if ((data.entities.datetime && data.entities.datetime.length) || (data.entities.number && data.entities.number.length)) {
				time = data.entities.datetime ? getYear(data.entities.datetime[0].values[0]) :
				data.entities.number[0].value;
 			}
		 if (data.entities.personRole) {
		 	role = data.entities.personRole[0].value;
		 }
		 if (data.entities.genre_name) {
		 	genre = data.entities.genre_name[0].value
		 }

		 entities = {person: modifyText(person),
			time: time ? time : null,
			role: role ? role : null,
			genre: genre ? genre : null}

		return {
			intent: 'get_movies_by_time_and_person',
			entities
		}
	} else if (data.entities.intent && data.entities.intent[0].value === 'get_cast') {
		if (data.entities && data.entities.movie_name && data.entities.movie_name.length) {
			return {
				intent: 'get_cast',
				entities: [modifyText(data.entities.movie_name[0].value)]
			}
		}
	} else if (data.entities.intent && data.entities.intent[0].value === 'get_person_by_role') {

		if (data.entities && data.entities.movie_name && data.entities.movie_name.length && data.entities.personRole && data.entities.personRole.length) {
			return {
				intent: 'get_cast',
				entities: [modifyText(data.entities.movie_name[0].value)]
			}
		}
	} else if (data.entities.intent && data.entities.intent[0].value === 'get_genre_based_movies') {
		if (data.entities && data.entities.genre_name && data.entities.genre_name.length) {
			return {
				intent: 'get_genre_based_movies',
				entities: [modifyText(data.entities.genre_name[0].value)]
			}
		}
	} else if ( (data.entities.intent && data.entities.intent[0].value === 'get_person_best_movies') &&
			(data.entities.personName && data.entities.personName[0].value)
		) {

		let person;
			if (data.entities.personName && data.entities.personName[0].value){
				person = data.entities.personName[0].value;
			} else if (data.entities.notable_person && data.entities.notable_person[0].value.name) {
				person = data.entities.notable_person[0].value.name;
			}

			return  {
				intent: 'get_person_best_movies',
				entities: modifyText(person)
			}
	}
	else if (data.entities.intent && data.entities.intent[0].value === 'get_fact_verification') {
		let people = [];
		if (data.entities.personName && data.entities.personName.length) data.entities.personName.map((item) => people.push(item.value));
		if (data.entities.notable_person && data.entities.notable_person.length) data.entities.notable_person.map((item) => people.push(item.value.name));

		return {
			intent: 'get_fact_verification',
			entities: {
				"entityOne": people[0] ? people[0] : '',
				"entityTwo": data.entities.movie_name ? data.entities.movie_name[0].value : '',
				"relation": data.entities.personRole ? data.entities.personRole[0].value : ''
			}
		}
	} else if (data.entities.intent && data.entities.intent[0].value === 'get_movies_people_combo') {
		let people = [];
		if (data.entities.personName && data.entities.personName.length) data.entities.personName.map((item) => people.push(item.value));
		if (data.entities.notable_person && data.entities.notable_person.length) data.entities.notable_person.map((item) => people.push(item.value.name));

 		return {
 			intent : 'get_movies_people_combo',
 			entities: {
 				entityOne: people[0] ? people[0] : '',
 				entityTwo:  people[1] ? people[1] : '',
 			}
 		}
	} else if (data.entities.intent && data.entities.intent[0].value === 'get_top_movies_by_time') {
		if (data.entities && data.entities.datetime && data.entities.datetime.length) {
			return {
				intent: 'get_top_movies_by_time',
				entities: [getYear(data.entities.datetime[0].values[0])]
			}
		}
	} else if (data.entities.intent && data.entities.intent[0].value){
		return {
			intent: data.entities.intent[0].value,
			entities: {}
		}
	} else {
		return {
			intent: null
		}
	}
}

function modifyText(text) {
	text = text.split(' ')
		.map((s) => s.charAt(0).toUpperCase() + s.substring(1))
		.join(' ');
	return text;
}

function getYear(data) {

	if (data.from) {
		return data.from.value.substring(0, 4).trim();
	} else if (data.value) {
		return data.value.substring(0, 4).trim()
	} else {
		return data.substring(0, 4).trim();
	}
}
export default ResolveEntities;