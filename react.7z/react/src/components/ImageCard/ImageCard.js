import React, { Component } from 'react';
import { Image, StyleSheet, View } from 'react-native';
import { H1, H2, H3, Container, Header, Content, Card, CardItem, Thumbnail, Text, Button, Icon, Left, Body } from 'native-base';
import ImageCustom from './../ImageCustom';

export default class ImageCard extends Component {

render() {
	const {name, image, roles, bornOn, diedOn, summary, isMovie, genre, releaseYear, rating } = this.props.data;
	let text;
	if (roles) {
		text = roles;
		text = text.split(',')
		.map((s) => s.charAt(0).toUpperCase() + s.substring(1))
		.join(', ');
	}
	return (
			<Card style={{flex: 0}}>
				<CardItem>
					<Left style={{flex: 1, justifyContent:'space-between'}}>
						<View>
							<H3>{name}</H3>
							{roles ? <Text note style={{marginLeft: 0}}>{text}</Text> : null}
						</View>
						<ImageCustom name={name} uri={image} isMovie={isMovie}/>
					</Left>
				</CardItem>
				<CardItem>
				  <Body>
					{bornOn ?
						<Text>
							<Text style={styles.boldText}>Born: </Text>
							<Text style={styles.responseText}>{bornOn}</Text>
						</Text> :
						null
					}
					{ diedOn ?
						<Text>
							<Text style={styles.boldText}>Died: </Text>
							<Text style={styles.responseText}>{diedOn}</Text>
						</Text> :
						null
					}
					{genre ?
						<Text>
							<Text style={styles.boldText}>Genre: </Text>
							<Text style={styles.responseText}>{genre}</Text>
						</Text> :
						null
					}
					{rating ?
						<Text>
							<Text style={styles.boldText}>Rating: </Text>
							<Text style={styles.responseText}>{rating}</Text>
						</Text> :
						null
					}
					{releaseYear ?
						<Text>
							<Text style={styles.boldText}>Release Year: </Text>
							<Text style={styles.responseText}>{releaseYear}</Text>
						</Text> :
						null
					}
					{summary ?
						<Text numberOfLines={3} style={styles.responseText}>
							<Text style={styles.boldText}>Details: </Text>{summary}
						</Text>:
						null
					}
				  </Body>
				</CardItem>
			{false ?
				<CardItem style={styles.iconButtonContainer}>
			  <Left>
				<Button style={styles.iconButton} transparent textStyle={{color: '#87838B'}}>
					{/*<Icon name="logo-youtube" />*/}
					{/*<Thumbnail small source={{uri: '../../images/Youtube-icon.png'}}*/}
					<Image source={require('../../images/Youtube-icon.png')} style={{width: 35, height: 35}} />
					<Text style={{fontSize: 7}}>YouTube</Text>
				</Button>
				<Button style={styles.iconButton} transparent textStyle={{color: '#87838B'}}>
					<Image source={require('../../images/google.png')} style={{width: 35, height: 35}} />
					<Text style={{fontSize: 7}}>Google</Text>
				</Button>
				<Button style={styles.iconButton} transparent textStyle={{color: '#87838B'}}>
					<Image source={require('../../images/imdb.png')} style={{width: 35, height: 35}} />
					<Text style={{fontSize: 7}}>IMDB</Text>
				</Button>
			  </Left>
			</CardItem>	:
			 null
			 }
		  </Card>
		);
	}
}

const styles = StyleSheet.create({
	responseText: {
		fontSize:13
	},
	boldText: {
		fontSize:13,
		fontWeight: 'bold'
	},
	iconButton: {
		flexDirection: 'column',
		flex: 1,
		height:60,
		justifyContent: 'space-around',
		alignItems:'center'
	},
	iconButtonContainer: {
		flexDirection: 'row',
		flex: 1,
		alignItems:'center',
		justifyContent: 'space-around'
	}
})