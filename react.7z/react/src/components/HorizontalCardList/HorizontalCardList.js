import React, { Component } from 'react';
import { Card, CardItem, Text, Left, Body } from 'native-base';
import { Image, FlatList, TouchableOpacity} from 'react-native';
import ImageCustom from './../ImageCustom';

export default class HorizontalCardList extends Component {
    onPressButton = (item) => () => {
        this.props.cardPressed({value: item});
    }

    keyExtractor = (item, index) =>  index.toString();

    render() {
        return (
            <FlatList
                horizontal={true}
                data={this.props.data}
                keyExtractor={this.keyExtractor}
                renderItem={({ item, index }) =>
                    <TouchableOpacity onPress={this.onPressButton(item)}>
                    <Card style={{ width: 150, height: 250 }} >
                        <CardItem cardBody>
                            <ImageCustom
                                uri={item.image}
                                isMovie={item.isMovie}
                                customStyle={{height: 150, width: 75, flex: 1}}
                                name={item.name}
                            />
                        </CardItem>
                        <CardItem>
                            <Left>
                                <Body>
                                    <Text numberOfLines={2}>{item.name}</Text>
                                    <Text numberOfLines={2}note>{item.roles ? item.roles : item.genre}</Text>
                                </Body>
                            </Left>
                        </CardItem>
                    </Card>
                    </TouchableOpacity>
                }
            />
        );
    }
}

