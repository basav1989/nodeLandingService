import React, { Component } from 'react';
import {Text, TouchableHighlight, View} from 'react-native';

export default class ButtonList extends Component {
	buttonPress = (data) => {
		this.props.buttonPressed(data);
	}

	keyExtractor = (item, index) =>  index.toString();

	getButtonList = (suggestions, name) => {
		const buttons = suggestions.map((item, index) => {
			return (<View
				title={item}
				key={index}
				style={{ margin: 10, height: 35, justifyContent: 'center', backgroundColor: 'rgb(18, 147, 154)', borderRadius: 5 }} >
				<TouchableHighlight onPress={() => this.buttonPress({ intent: item, personName: name })} underlayColor='rgb(11, 107, 142)'>
					<Text style={{ height: 'auto', width: 'auto', color: '#fff', margin: 10 }}>{item}</Text>
				</TouchableHighlight>

				</View>);
		});
		return buttons;
	}
	render() {
		const {name, suggestions}  = this.props.data;
		return (
			<View style={{ flex: 1, flexDirection: 'row' }}>
				{
					this.getButtonList(suggestions, name)
				}
			</View>
		);
	}
}

