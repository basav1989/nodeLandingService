import React, { Component } from 'react';
import {Card, CardItem, Body, Text } from 'native-base';

import {View} from 'react-native';

const CustomCard = ({msg}) => (
		 <Card>
			<CardItem>
				<Body>
					<Text>
						{msg}
					</Text>
				</Body>
			</CardItem>
		</Card>
	);

export default CustomCard;