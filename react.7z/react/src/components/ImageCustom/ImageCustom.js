import React, { Component } from 'react';
import { Image } from 'react-native';

export default class ImageCustom extends Component {
	constructor(props) {
		super(props);
		this.state = {
			image: { uri: props.uri ?
				props.uri :
				`http://10.221.31.64:${props.isMovie ? 5200 : 5100}/${props.name}.jpg` }
		}
	}
	onError(error){
		this.setState({ image: this.props.isMovie ?
		require("../../images/defaultMovie.png") :
		require("../../images/defaultIcon.png")})
	}
	render() {
		const {customStyle} = this.props;
		return (
			<Image
				source={ this.state.image }
				style={customStyle ? customStyle : {borderRadius:50, width: 75, height: 75}}
				onError={ this.onError.bind(this) }
			/>
		);
	}
}
