import React, { Component } from 'react';
import {Button, Container, Content, Item, Input, Icon } from 'native-base';
import { Image, StyleSheet, Text, View} from 'react-native';

import Voice from 'react-native-voice';

export default class InputComponent extends Component {
	constructor(props) {
		super(props);
		this.state = {
			value: '',
			listening: false,
			error: '',
			results: [],
		}

		Voice.onSpeechError = this.onSpeechError.bind(this);
		Voice.onSpeechEnd = this.onStopRecognizing.bind(this);
		Voice.onSpeechPartialResults = this.onSpeechPartialResults.bind(this);
		this.voice = () => {
			_startRecognizing();
			this.setState({
				listening: true
			});
		}

		this.submit = () => {
			const val = this.state.value.trim();
			if (val) this.props.onSubmit(val);
			this.setState({
				value: ''
			});
		}

		async function _startRecognizing () {
			try {
				await Voice.start('en-US');
			} catch (e) {
				console.error(e);
			}
		}
	}

	updateValue(text) {
		this.setState({
			value: text
		});
 	}

	onSpeechError(e) {
		this.setState({
			error: JSON.stringify(e.error),
		});
	}

	onSpeechPartialResults(e) {
		this.setState({
			results: e.value,
		});
	}

	onStopRecognizing(e) {
		if (this.state.results.length) this.props.onSubmit(this.state.results);
		this.setState({
			listening: false,
		});
	}

	componentWillUnmount() {
		Voice.destroy().then(Voice.removeAllListeners);
	}

	render() {
		return (
			<View style={styles.container}>
				{this.state.listening ?
					<Image style={styles.microphone}
						source={require('../../images/microphone.gif')}
					/> : (<View style={styles.input}>
				<Input
					placeholder='Say something...'
					onChangeText={(text)=> this.updateValue(text)}
					onSubmitEditing={()=>this.submit()}
					value={this.state.value}
				/>
				<View style={styles.submit}>
					{ this.state.value ?
						<Button
							primary
							transparent
							rounded
							small
							style={styles.button}
							onPress={()=>this.submit()}
						>
							<Icon active name='send'/>
						</Button> :
						<Button
							primary
							transparent
							rounded
							small
							style={styles.voice}
							onPress={() => this.voice()}
						>
							<Icon active name="mic" style={styles.mic} />
						</Button>
					}
				</View>
				</View>)}
			</View>
		);
	}
}

const styles = StyleSheet.create({
	container: {
		display: 'flex', flexDirection: 'column', backgroundColor: '#eee'
	},
	microphone: {
		height: 80, width: null
	},
	input: {
		display: 'flex', flexDirection: 'row'
	},
	submit: {
		paddingTop: 10
	},
	button: {
		alignItems: "center", justifyContent: "center"
	},
	voice: {
		alignItems: "center", justifyContent: "center"
	},
	mic: {
		color: 'lightseagreen'
	}
});
