import React, { Component } from 'react';
import {View, StyleSheet, Text} from 'react-native';

const CustomBadge = ({msg, customStyle, msgColor, ...rest}) => (
		<View style={[customStyle, styles.info]}>
			<View style={{ flex: 1, flexGrow: 1 }}>
				<Text
					style={[styles.containerStyle, msgColor]}
					allowFontScaling={false}
				>
					{msg}
				</Text>
			</View>
		</View>
	);

const styles = StyleSheet.create({
	info: {
		width: 50,
		flexGrow: 1
	},
	containerStyle: {
		fontSize: 16,
		borderWidth: 1,
		borderRadius: 25,
		padding: 10,
		borderColor: '#ddd',
		borderBottomWidth: 0,
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 5 },
		shadowOpacity: 0.9,
		shadowRadius: 2,
		elevation: 5,
		marginLeft: 5,
		marginRight: 5,
		marginTop: 10,
		color: '#fff'
	}
});

export default CustomBadge;