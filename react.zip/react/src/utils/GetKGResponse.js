
GetKGResponse = async (intent, entities, isSuggestion) => {

	const url =	isSuggestion ?
		`http://10.221.31.64:5600/suggestionQry` :
		`http://10.221.31.64:5600/natLangQry`;
	const request =  {
		'method': 'POST',
		headers: {
			'Accept': 'application/json',
	    	'Content-Type': 'application/json'
		},
		body: JSON.stringify({
			intent: intent,
			entity: entities

		})
	  };

	const response = await fetch(url, request);
	const data = await response.json();
	return data ? data : null;
}

export default GetKGResponse;