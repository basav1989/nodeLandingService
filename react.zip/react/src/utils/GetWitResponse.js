
GetWitResponse = async (value) => {

	const MY_WIT_TOKEN = 'M6272FQ3BBDTXINN3NX2JFS6XVHISLCU'; // - KG api

	const url = `https://api.wit.ai/message?q=${value}`;
	const headers =  {
		method: 'GET',
		headers: {Authorization: `Bearer ${MY_WIT_TOKEN}`}
	};

	// call to Wit.ai for intents and entities
	const response = await fetch(url, headers);
	const data = await response.json();
 	return data;
}

export default GetWitResponse;