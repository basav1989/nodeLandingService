import GetKGResponse from './GetKGResponse';
import {IntentRouter, checkData} from './IntentRouter';

GetSuggestionResponse = async (intent, entities) => {
	let processedData;
	const data = await GetKGResponse(intent, entities, true);
	// data.isMovie = data.length && data[0].genre ? true : false;
	if (data) {
		processedData = processResponse(data);
	}
	return processedData ? processedData : null;
}

function processResponse (data) {
	let witData = {entities:{intent:[{value:'suggestion'}]}};
	if (data.length) {
		data.map((item, index)=> {
			item.isMovie = item.hasOwnProperty('rating') ? true : false;
			item.image = item.isMovie ? `http://10.221.31.64:5200/${item.name}.jpg` : `http://10.221.31.64:5100/${item.name}.jpg`;
			return item;
		});
	}
	const dataProcessed = checkData(data, witData);
	return dataProcessed;
}

export default GetSuggestionResponse;