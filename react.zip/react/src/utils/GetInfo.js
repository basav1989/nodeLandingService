import GetKGResponse from './GetKGResponse';

GetInfo = async ({intent, entities}) => {
	const data = await GetKGResponse(intent, entities);
	// if (data.length) data[0].isMovie = data.length && data[0].genre ? true : false;
	data.map((item) => {
		item.isMovie = item.genre ? true : false;
		item.image = item.isMovie ? `http://10.221.31.64:5200/${item.name}.jpg` : `http://10.221.31.64:5100/${item.name}.jpg`;
		return item;
	});
	//get the name and make a call to get summary of Actor
	const url = data.length && data[0].isMovie ? `http://10.221.31.64:5200/${data[0].name}summary.txt`:
	 `http://10.221.31.64:5100/${entities.person}summary.txt`;
	const request = {
		method: 'GET',
		headers: {
			'Accept': 'text/html',
			// 'Content-Type': 'application/json',
			'Accept-Language':'en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7',
			'Accept-Encoding': 'gzip, deflate'
		}
	}

	const response3 = await fetch(url, request);
	const summary = await response3.text();

	if (summary && data && data.length) data[0].summary = summary;
	if (data.isMovie && data && data.length) {
		data[0].genre = data[0].genre.split(",").join(", ");
	}
	return data.length ? data : null;
}

export default GetInfo;