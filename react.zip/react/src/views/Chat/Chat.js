import React, { Component } from 'react';
import { FlatList, KeyboardAvoidingView, StyleSheet, View, Text, TextInput, TouchableOpacity, ScrollView } from 'react-native';

import Tts from "react-native-tts";

import CustomBadge from '../../components/CustomBadge';
import CustomCard from '../../components/CustomCard';
import ImageCard from '../../components/ImageCard';
import HorizontalCardList from '../../components/HorizontalCardList';
import ButtonList from '../../components/ButtonList';

let flatlistRef;

class Chat extends Component {
	constructor(props) {
		super(props);
		this.state = {
			collection: [],
			ttsStatus: "initiliazing",
		}
		this.renderItem = this.renderItem.bind(this);

		Tts.getInitStatus().then(() => {
			this.initTts();
		});
	}

	initTts = async () => {
		this.setState({ ttsStatus: "initialized" });
	};

	componentWillReceiveProps(nextProps) {
		setTimeout(() => this.refs.flatlistRef.scrollToEnd(), 200)
		if (nextProps.msg) {
			this.setState({
				collection: [...this.state.collection, ...nextProps.msg]
			});
		}
		this.voiceReadOut(nextProps.msg);
	}

	voiceReadOut = async (val) => {
		if (this.state.ttsStatus === 'initialized' && val && val.length && val[0].bot) {
			let text = val[0].bot;
			if (val.length > 1 && val[1].data) {
				if (val[1].data['name']) text = text + ' for ' + val[1].data['name'] + '. ';
				// if (val[1].data['summary']) {
				// 	var summary = val[1].data['summary'];
				// 	text = text + summary.substr(0, summary.indexOf('.') + 1);
				// }
			}
			 else if (val.length > 1 && val[1].bot) {
				text = text + val[1].bot;
			}
			Tts.stop();
			Tts.speak(text);
		}
	};

	renderItem = ({ item, index }) => {
		switch (item.type) {
			case 'text':
				return (<View
					style={{ margin: 5, flexDirection: 'row' }}
					key={index}
				>
					<CustomBadge
						msg={item.bot ? item.bot : item.user}
						customStyle={item.bot ? styles.botMsg : styles.userMsg}
						msgColor={item.bot ? styles.botMsgDisplay : styles.userMsgDisplay}
					/>
				</View>)
				break;
			case 'customCard':
				return (<CustomCard key={index} msg={item.bot} />);
				break;
			case 'imageCard':
				return (<View key={index} style={{ padding: 10 }}>
					<ImageCard data={item.data} />
				</View>);
				break;
			case 'horizontalCardList':
				return (
					<View
						key={index}
						style={{ padding: 10 }}
					>
						<HorizontalCardList
							data={item.data}
							cardPressed={this.props.cardPress}
						/>
					</View>
				);
				break;
			case 'buttonList':
				return (
					<View
						key={index}
						style={{ padding: 10 }}
					>
						<ButtonList
							data={item.data}
							buttonPressed={this.props.buttonPress}
						/>
					</View>
				);
				break;

			 default:
				return null;
		}
	}

	scrollEnd (contentHeight) {
		this.scrollView.scrollToEnd({animated: true});
	}

	keyExtractor = (item, index) => index.toString();

	muteVoice = () => {
		Tts.stop();
	}
	render() {
		const props = Object.assign({}, this.props);
		return (
			// <TouchableOpacity style={{ flex: 1 }} activeOpacity={1} onPress={this.muteVoice}>
			<FlatList
				key={'chat'}
				ref='flatlistRef'
				style={{ flex: 1 }}
				data={this.state.collection}
				extraData={this.state}
				renderItem={this.renderItem}
				keyExtractor={this.keyExtractor}
			/>
			// </TouchableOpacity>
		);
	}
}

const styles = StyleSheet.create({
	container: {
		width: '100%',
		height: '100%',
		backgroundColor: 'white',
	},
	botMsg: {
		alignItems: 'flex-start',
		paddingLeft: 5
	},
	botMsgDisplay: {
		backgroundColor: 'rgb(18, 147, 154)'
	},
	userMsgDisplay: {
		backgroundColor: 'rgb(11, 107, 142)'
	},
	userMsg: {
		alignItems: 'flex-end',
		paddingRight: 5
	}
})

export default Chat;
